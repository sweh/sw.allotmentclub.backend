=================================
The gocept.loginuser distribution
=================================

Sqlalchemy user object and password management.

This package is compatible with Python version 2.7.
