# Copyright (c) 2015 gocept gmbh & co. kg
# See also LICENSE.txt

_year_started = 2015

import gocept.package.sphinxconf
gocept.package.sphinxconf.set_defaults()
